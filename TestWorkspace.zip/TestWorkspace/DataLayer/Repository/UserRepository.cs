﻿using BusinessLayer;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Repository
{
    public class UserRepository : BaseRepository
    {
        public UserRepository(DemoDbContext datacontext) : base(datacontext) { }

        public UserDetails AddRecord()
        {
            return null;
        }
        
    }
}
