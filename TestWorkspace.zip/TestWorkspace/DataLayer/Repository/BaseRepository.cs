﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Repository
{
    public abstract class BaseRepository
    {
        protected readonly DemoDbContext _DataContext;

        public BaseRepository(DemoDbContext datacontext)
        {
            _DataContext = datacontext;
        }
    }
}
