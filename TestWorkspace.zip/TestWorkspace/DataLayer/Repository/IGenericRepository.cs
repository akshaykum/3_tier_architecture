﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Repository
{
    public interface IGenericRepository<T1, T2>
    {
        // [GauravSharma 27/08/2019] - Basic CRUD Operations.

        // Operation 1. Add Record. This function will add the record into the database.
        T1 AddRecord(T1 record);

    }
}
