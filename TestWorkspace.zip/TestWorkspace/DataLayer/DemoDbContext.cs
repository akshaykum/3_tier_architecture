﻿using BusinessLayer;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public class DemoDbContext : IdentityDbContext<ApplicationUser>
    {
        public DemoDbContext(DbContextOptions<DemoDbContext> options) : base(options) { }
        public DbSet<User> NewUser { get; set; } 
        public DbSet<UserDetails> UserDetails { get; set; } 
    }

    
}
