﻿using DataLayer;
using DataLayer.Repository;
using DemoApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace DemoApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly DemoDbContext _demoDbContext;
        private readonly UserRepository _UserRepository;

        public HomeController(ILogger<HomeController> logger, DemoDbContext demoDbContext, UserRepository UserRepository)
        {
            _logger = logger;
            _demoDbContext = demoDbContext;
            _UserRepository = UserRepository as UserRepository;
        }

        public IActionResult Index()
        {
            _UserRepository.AddRecord();
            return null;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
